from django.db import models
from django.contrib.auth.models import User
from ckeditor_uploader.fields import RichTextUploadingField
from taggit.managers import TaggableManager
from django.template.defaultfilters import slugify
# Create your models here.

STATUS = (
    (0,"Draft"),
    (1,"Publish")
)


class BlogCategory(models.Model):
    category_name = models.CharField(max_length=100,unique=True)

    def __str__(self):
        return self.category_name


class BlogModel(models.Model):

    title = models.CharField(max_length=100, unique=True)
    slug = models.SlugField(max_length=200, unique=True)
    subtitle = models.CharField(max_length=100, unique=True, null=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='blog_posts')
    meta_title = models.CharField(max_length=100, null=True)
    meta_keyword = models.CharField(max_length=200, null=True)
    meta_description = models.CharField(max_length=250, null=True)
    icon = models.ImageField(upload_to="images/")
    banner_img = models.ImageField(upload_to="images/")
    outer_page_info = models.CharField(max_length=90, null=True)
    blog_category = models.ForeignKey('BlogCategory', on_delete=models.CASCADE)
    inner_bg_img = models.ImageField(upload_to="images/", null=True)
    content = RichTextUploadingField(blank=True)
    created_on = models.DateTimeField(auto_now_add=True)
    updated_on = models.DateTimeField(auto_now=True)
    published_date = models.DateTimeField(null=True)
    tags = TaggableManager()
    status = models.IntegerField(choices=STATUS, default=0)

    class Meta:
        ordering = ['-created_on']



    def __str__(self):
        return self.title



class CommentsModel(models.Model):
    post=models.ForeignKey(BlogModel,on_delete=models.CASCADE)
    comment=models.TextField()
    name = models.CharField(max_length=100, null=True, blank=True)
    email = models.EmailField(blank=True)
    phone = models.CharField(max_length=12, null=True, blank=True)
    created_on=models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.comment



class SentMessage(models.Model):
    name = models.CharField(max_length=50)
    email = models.EmailField()
    subject = models.CharField(max_length=100)
    message = models.TextField()

    def __str__(self):
        return self.name



class OurClick(models.Model):
    photo = models.ImageField(upload_to="our_clicks",null=True,blank=True)
    title = models.CharField(max_length=30,null=True,blank=True)
    uploaded_on = models.DateTimeField(auto_now_add=True)
    author = models.ForeignKey(User,related_name="ourclicks_author",on_delete=models.CASCADE,null=True,blank=True)
    users_like  = models.ManyToManyField(User,blank=True,null=True)

    def __str__(self):
        return str(self.id)

