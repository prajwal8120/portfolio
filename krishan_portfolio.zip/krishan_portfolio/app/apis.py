from rest_framework.views import APIView
from app.models import SentMessage
from django.core.mail import EmailMessage
from rest_framework.response import Response

class SentMessageAPIView(APIView):
    def post(self,*args,**kwargs):
        name = self.request.data['name']
        email = self.request.data['email']
        subject = self.request.data['subject']
        message = self.request.data['message']
        try:

            if name and email and subject and message:
                # email_msg = EmailMessage(
                #     subject=subject,
                #     body=email_html_template,
                #     from_email=settings.DEFAULT_FROM_EMAIL,
                #     to=[email]
                # )
                # email_msg.content_subtype = 'html'
                # ssl._create_default_https_context = ssl._create_unverified_context
                # email_msg.send(fail_silently=False)
                obj = SentMessage(name=name,email="krishn.kumar.patel6163@gmail.com",subject=subject,message=message)
                if obj:
                    obj.save()
                    return Response({'msg':'ok','message':'message sent successfully.'})
        except:
            return Response({'msg':'ko','message':'message did not send,please try again.'})
        return Response({'msg': 'ko', 'message': 'message did not send,please try again.'})