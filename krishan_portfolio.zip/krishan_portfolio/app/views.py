from django.shortcuts import render
from django.views.generic import TemplateView,DetailView,ListView
from app.models import BlogModel,OurClick
# Create your views here.

class IndexView(ListView):
    template_name="app/index.html"
    model = BlogModel

    def get_context_data(self,*args,**kwargs):
        context = super().get_context_data(*args,**kwargs)
        our_clicks = OurClick.objects.all().select_related()
        context['our_clicks'] = our_clicks
        return context


class BlogDetailView(DetailView):
    template_name = 'app/blog-single.html'
    model = BlogModel