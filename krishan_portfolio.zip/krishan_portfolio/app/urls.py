from django.urls import path
from .views import *
from .apis import *
app_name = 'app'

urlpatterns = [
    path('',IndexView.as_view(),name='index'),
    path('api/send-message/',SentMessageAPIView.as_view()),
    path('<slug:slug>/',BlogDetailView.as_view(),name="blog_details"),
]