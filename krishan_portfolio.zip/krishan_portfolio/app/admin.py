from django.contrib import admin
from .models import *
# Register your models here.

class BlogAdmin(admin.ModelAdmin):

    list_display = ('title', 'slug', 'status', 'created_on')
    list_filter = ("status",)
    search_fields = ['title', 'content']
    prepopulated_fields = {'slug': ('title',)}


class BlogCategoryAdmin(admin.ModelAdmin):

    list_display = ('category_name',)
    list_filter = ("category_name",)
    search_fields = ['category_name']


class CommentsModelAdmin(admin.ModelAdmin):

    list_display = ('comment',)
    list_filter = ("comment",)
    search_fields = ['comment']

class SentMessageAdmin(admin.ModelAdmin):
    list_display = ['name','email','subject','message']


class OurClickAdmin(admin.ModelAdmin):
    list_display = ['title','photo','uploaded_on','author']


admin.site.register(BlogModel,BlogAdmin)
admin.site.register(OurClick,OurClickAdmin)
admin.site.register(BlogCategory,BlogCategoryAdmin)
admin.site.register(CommentsModel,CommentsModelAdmin)
admin.site.register(SentMessage,SentMessageAdmin)