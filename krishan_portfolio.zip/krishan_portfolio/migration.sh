#!/bin/bash

# echo "Manage static file storage"

# python manage.py collectstatic --no-input

# returnCode=$?

# if [ $returnCode -ne 0 ]; then
#     echo "An Error occurred in collectstatic step"
#     exit 1
# fi

# Apply database migrations
echo "Apply database migrations"
echo

echo "[DEBUG] DB ENDPOINT: $DB_HOST:$DB_PORT"

python manage.py migrate --no-input

returnCode2=$?

if [ $returnCode2 -ne 0 ]; then
    echo "An Error occurred in migrate step"
    exit 1
fi

echo

echo "Migration Script Finished."



